﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceExample2
{
    enum Mobile {nokia, samsung,iphone,micromax,lava }//enumerator - a user defined data type

    //Interfaces only have method declarations
    //These methods will have to be mandatorily define in classes implementating these interfaces
    interface IAudioModule
    {
        void AudioJack3_5mm();
    }

    interface IMobile
    {
        bool MicroUSBCharger();
        void MyMethod();
    }

    class Nokia: IMobile, IAudioModule //Implmentation - Multiple implementation only applicable to interfaces not classes - Only multi level inheritance is possible
    {
        public bool MicroUSBCharger()
        {
            //
            return true;
        }

        public void AudioJack3_5mm()
        {
            //Implementation for audio jack
        }

        public void MyMethod() { }

        public void NokiaMethod() { }
    }

    class IPhone : IMobile
    {
        public bool MicroUSBCharger()
        {
            //
            return true;
        }
        public void MyMethod() { }
    }

    class Samsung : IMobile,IAudioModule //This is multiple interface implementation. This is not possible with inheritance of classes
    {
        public void AudioJack3_5mm()
        {
            throw new NotImplementedException();
        }

        public bool MicroUSBCharger()
        {
            //
            return true;
        }

        public void MyMethod() { }
    }

    class Program
    {
        static void Main(string[] args)
        {
            ConditionalStatements();

            Mobile m = Mobile.lava;
            Mobile m5 = Mobile.micromax;
            
            Nokia m1 = new Nokia();
            m1.MicroUSBCharger();
            Samsung m2 = new Samsung();
            m2.MicroUSBCharger();

            IMobile m3 = new Nokia();
            m3.MicroUSBCharger();

            //Type Casting
            Nokia m3UpdateRef = (Nokia)m3;
            m3UpdateRef.NokiaMethod();

            IMobile m4 = new Samsung();
            IAudioModule am1 = new Samsung();
            Samsung s = (Samsung)am1;
        }

        public static void ConditionalStatements()
        {
            
            int i = 7;
            Mobile m = Mobile.iphone;

            string result = i < 10 ? "pass" : "fail";//tertiary

            //Conditional statement
            if (i==1)
            {

            }
            else if(i==2)
            {

            }
            else
            {

            }

            switch (m)
            {
                case Mobile.iphone:
                    Console.WriteLine("In case 1");
                    break;
                case Mobile.lava:
                    Console.WriteLine("In case 2");
                    break;
                case Mobile.nokia:
                    Console.WriteLine("In case 3");
                    break;
                case Mobile.micromax:
                    Console.WriteLine("In case 4");
                    break;
                case Mobile.samsung:
                    Console.WriteLine("In case 5");
                    break;
                default:
                    Console.WriteLine("In default case");
                    break;
            }

            Console.ReadKey();
        }
    }
}
